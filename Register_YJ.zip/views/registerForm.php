    <!-- Custom fonts for this template-->
	  <script src="/~sale11/my/js/team411_intlTelInput.js"></script> <!-- API -->
<script src="https://code.jquery.com/jquery-latest.min.js"></script> <!-- API -->
<script src="/~sale11/my/js/team411_intlTelInput-jquery.min.js"></script> <!-- API -->
    <link href="/~sale11/my/js/team4_all.min.css" rel="stylesheet" type="text/css">
<!--     <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet"> -->
<link href="/~sale11/my/js/team411_intlTelInput.css" rel="stylesheet"> <!-- API -->
<!--  <link rel="stylesheet" href="/~sale11/my/js/team411_demo.css"> -->
    <!-- Custom styles for this template -->
    <link href="/~sale11/my/js/team4_sb-admin-2.min.css" rel="stylesheet">
    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                    <div class="col-lg-7">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">가입허실?</h1>
                            </div>
                            <form class="user" name="form2" method="post" action="/~sale11/register">
                                <div class="form-group row">
                                    <div class="col-sm-4 mb-3 mb-sm-0">
                                        <input type="text" name="uid" class="form-control form-control-user" id="exampleFirstName"
                                            placeholder="아이디를 입력하세요">
                                    </div>
                                    <div class="col-sm-4">
                                        <input type="password" name="pwd" class="form-control form-control-user" id="exampleInputPassword"
                                            placeholder="암호를 입력하세요">
                                    </div>
									<div class="col-sm-4">
                                        <input type="text" name="name" class="form-control form-control-user" id="exampleLastName"
                                            placeholder="이름을 입력하세요">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control form-control-user" id="exampleInputEmail"
                                        placeholder="이메일 주소를 입력하세요">
                                </div>
                           <div class="form-group row">
                                    <div class="col-sm-4 mb-3 mb-sm-0">
											<input type="tel" name="phone" id="phone" 
											 class="form-control form-control-user"  value=""  placeholder="전화번호 앞 3자리">
                                    </div>
									<div class="col-sm-4 mb-3 mb-sm-0">
											<input type="text" name="phone2" 
											 class="form-control form-control-user" size="4" maxlength="4" value="" placeholder="전화번호 중간 4자리">
                                    </div>
									<div class="col-sm-4 mb-3 mb-sm-0">
											<input type="text" name="phone3" 
											 class="form-control form-control-user" size="4" maxlength="4" value="" placeholder="전화번호 뒤 4자리">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-user btn-block">
									회원가입
								</button>  
								<hr>
<!--                                 <a href="/~team4/login" class="btn btn-google btn-user btn-block">
                                    <i class="fab fa-google fa-fw"></i> 구글로 로그인
                                </a>
                                <a href="/~team4/login" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> 페이스북으로 로그인
                                </a> -->
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="#">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="#">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
	
	  <script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
    //  geoIpLookup: function(callback) {
      //  $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
        //  var countryCode = (resp && resp.country) ? resp.country : "";
         // callback(countryCode);
        //});
     // },
      // hiddenInput: "full_number",
     //  initialCountry: "auto",
      // localizedCountries: { 'de': 'Deutschland' },
    //   nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
    //   separateDialCode: true,
      utilsScript: "/~sale11/my/js/utils2.js", <!-- API, 기존 파일과 이름이 겹쳐 util2로 변경 -->
    });
  </script>
    <!-- Bootstrap core JavaScript-->
    <script src="/~sale11/my/js/team4_jquery.min.js"></script>
    <script src="/~sale11/my/js/team4_bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="/~sale11/my/js/team4_jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/~sale11/my/js/team4_sb-admin-2.min.js"></script>


</body>

</html>